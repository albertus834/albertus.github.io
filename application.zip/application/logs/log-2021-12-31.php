<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-31 18:01:17 --> 404 Page Not Found: ../modules/ahome/controllers//index
ERROR - 2021-12-31 18:01:19 --> 404 Page Not Found: ../modules/ahome/controllers//index
ERROR - 2021-12-31 18:01:20 --> 404 Page Not Found: ../modules/ahome/controllers//index
ERROR - 2021-12-31 18:01:20 --> 404 Page Not Found: ../modules/ahome/controllers//index
ERROR - 2021-12-31 18:01:20 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:34 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:34 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:34 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:36 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:40 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:40 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:41 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:56 --> 404 Page Not Found: ../modules/ahome/controllers//index
DEBUG - 2021-12-31 18:01:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 18:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 18:01:56 --> 404 Page Not Found: /index
