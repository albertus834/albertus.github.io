<div class="content-wrapper">
    <?php $this->load->view('layout/header-page') ?>
    <!-- Main content -->
    <section class="content">
        <div class="col-12">
            <div class="card">
                <div class="tampil-modal"></div>
                <?= form_error('email', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
                <div class="flash-data" data-flashdata=""><?= $this->session->flashdata('message'); ?></div>
                <div class="card-body">
                    <div class="content">
                        <div class="panel">
                            <div class="panel-body">
                                <p>Pastikan Siswa sudah mengikuti proses <strong>daftar ulang</strong>, untuk pembuatan NIS Siswa Baru / Siswa Mutasi</p>
                            </div>
                            <div class="table-responsive">
                                <table id="example1" class="table table-bordered table-sm table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>NIS</th>
                                            <th>Nama</th>
                                            <th>JK</th>
                                            <th>TGL Lahir</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>


                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- jQuery -->
<script src="<?= base_url() ?>plugins/jquery/jquery.min.js"></script>