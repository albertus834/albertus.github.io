 <div class="card card-primary">
     <div class="card-header">
         <h3 class="card-title">About Me</h3>
     </div>
     <!-- /.card-header -->
     <div class="card-body">
         <strong><i class="fas fa-book mr-1"></i> Education</strong>
         <p class="text-muted">
             B.S. in Computer Science from the University of Tennessee at Knoxville
         </p>
         <hr>
         <strong><i class="fas fa-map-marker-alt mr-1"></i> Location</strong>
         <p class="text-muted"></p>
         <hr>
         <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam fermentum enim neque.</p>
     </div>
     <!-- /.card-body -->
 </div>